import tensorflow
import numpy

x = tensorflow.placeholder("float",[None,784])

w = tensorflow.Variable(tensorflow.)
